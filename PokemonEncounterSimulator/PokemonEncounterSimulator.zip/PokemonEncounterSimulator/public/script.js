// Predefined Pokemon for each environment
const encounterOptions = {
    mountain: ['geodude', 'zubat'],
    river: ['buizel', 'poliwag'],
    plains: ['eevee', 'pikachu']
};

// Array to hold caught Pokemon (could also be fetched from local storage)
let caughtPokemon = JSON.parse(localStorage.getItem('caughtPokemon')) || [];

// Function to get the count of caught Pokemon
function getCaughtPokemonCount() {
    return caughtPokemon.length;
}

// Function to add a caught Pokemon to the list
function addCaughtPok?mon(pokemon) {
    if (!caughtPok?mon.includes(pokemon)) {
        caughtPok?mon.push(pokemon);
        localStorage.setItem('caughtPokemon', JSON.stringify(caughtPokemon)); // Save to local storage
    }
}

function handleEncounter(environment) {
    const encounterResultDiv = document.getElementById('encounter-result');
    const pokemonList = getPokemonForEnvironment(environment);

    if (pokemonList.length > 0) {
        const encounteredPokemon = encounterPokemon(pokemonList);
        if (encounteredPokemon) {
            encounterResultDiv.innerHTML = `
                You encountered a ${capitalizeFirstLetter(encounteredPokemon.name)}!
                <img src="${encounteredPokemon.image}" alt="${encounteredPokemon.name}">
            `;
        } else {
            encounterResultDiv.innerHTML = "No Pokemon encountered.";
        }
    } else {
        encounterResultDiv.innerHTML = "No Pokemon available for this environment.";
    }
}

// This function can return Pokemon based on the selected environment
function getPokemonForEnvironment(environment) {
    const pokemonLineup = {
        mountain: [
            { name: "geodude", image: "https://img.pokemondb.net/sprites/home/normal/geodude.png" },
            { name: "zubat", image: "https://img.pokemondb.net/sprites/home/normal/zubat.png" }
        ],
        river: [
            { name: "buizel", image: "https://img.pokemondb.net/sprites/home/normal/buizel.png" },
            { name: "poliwag", image: "https://img.pokemondb.net/sprites/home/normal/poliwag.png" }
        ],
        plains: [
            { name: "eevee", image: "https://img.pokemondb.net/sprites/home/normal/eevee.png" },
            { name: "pikachu", image: "https://img.pokemondb.net/sprites/home/normal/pikachu.png" }
        ]
    };

    return pokemonLineup[environment] || [];
}

// Simulates a Pokemon encounter
function encounterPokemon(pokemonList) {
    // Randomly decide if an encounter occurs (50% chance)
    if (Math.random() < 0.5) {
        const randomIndex = Math.floor(Math.random() * pokemonList.length);
        return pokemonList[randomIndex]; // Return a random Pokemon
    }
    return null; // No Pokemon encountered
}


// Function to attempt to catch the Pok?mon
function attemptToCatch(pokemon) {
    const caughtPokemonCount = getCaughtPokemonCount();
    const catchSuccessRate = 0.5; // 50% chance to catch
    const catchButton = document.getElementById("catch-button");

    if (caughtPokemonCount >= 100) {
        catchButton.innerHTML = "Release Pokemon to Catch More";
        catchButton.disabled = true;
        return;
    }

    let success = Math.random() < catchSuccessRate;
    if (success) {
        addCaughtPokemon(pokemon);
        alert(`${capitalizeFirstLetter(pokemon)} has been caught!`);
    } else {
        alert(`${capitalizeFirstLetter(pokemon)} fled!`);
    }
}

// Function to capitalize the first letter of a string
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

// Function to display caught Pokemon on caught.html
function displayCaughtPokemon() {
    const listElement = document.getElementById('caught-pokemon-list');
    const caughtPokemon = JSON.parse(localStorage.getItem('caughtPokemon')) || [];

    if (caughtPokemon.length === 0) {
        listElement.innerHTML = '<p>You have not caught any Pokemon.</p>';
        return;
    }

    listElement.innerHTML = caughtPokemon.map(pokemon =>
        `<div>
      <span onclick="location.href='/pokemonDetail?name=${pokemon}'">${capitalizeFirstLetter(pokemon)}</span>
      <button onclick="releasePokemon('${pokemon}')">Release</button>
    </div>`).join('');
}

// Function to release a Pokemon from the caught list
function releasePokemon(pokemon) {
    if (confirm(`Are you sure you want to release ${capitalizeFirstLetter(pokemon)}?`)) {
        caughtPokemon = caughtPokemon.filter(p => p !== pokemon); // Remove from array
        localStorage.setItem('caughtPokemon', JSON.stringify(caughtPokemon)); // Update local storage
        displayCaughtPokemon(); // Refresh caught Pokemon list
    }
}

// Function to display Pokemon detail
function displayPokemonDetail() {
    const urlParams = new URLSearchParams(window.location.search);
    const pokemonName = urlParams.get('name');

    fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`)
        .then(response => response.json())
        .then(data => {
            const detailElement = document.getElementById('pokemon-detail');
            detailElement.innerHTML = `
        <h2>${capitalizeFirstLetter(data.name)}</h2>
        <img src="${data.sprites.front_default}" alt="${data.name}">
        <p>Types: ${data.types.map(typeInfo => capitalizeFirstLetter(typeInfo.type.name)).join(', ')}</p>
        <p>Height: ${(data.height / 10).toFixed(1)} m</p>
        <p>Weight: ${(data.weight / 10).toFixed(1)} kg</p>
      `;
        });
}
